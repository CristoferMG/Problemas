/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica 2023-2024
*
* @file inverso-2.cc
* @author Cristofer Marichal González - alu0101646480@ull.edu.es
* @date Oct 15 2023
* @brief El programa lee un número de valores elegidos con anterioridad y
*        devuelve esa cantidad de números pero en orden inverso.
* @bug There are no known bugs
* @see https://docs.google.com/document/d/1IVXL8p2OQH20hNdabSTur1dDnDyKI8XYvHtJt19KTjg/edit?usp=sharing
*/


#include <iostream>

int main() {
  int cantidad;
  std::cout << "Introduce la cantidad de números a ingresar: ";
  std::cin >> cantidad;
  
  int inverso[cantidad];

  std::cout << "Introduce una secuencia de números:" << std::endl;

  for (int i = 0; i < cantidad; i++) {
    std::cin >> inverso[i];
  }

  std::cout << "Números en orden inverso:" << std::endl;
  for (int i = cantidad - 1; i >= 0; i--) {
    std::cout << inverso[i] << " ";
  }

  std::cout << std::endl;

  return 0;
}
