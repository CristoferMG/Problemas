/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica 2023-2024
*
* @file media.cc
* @author Cristofer Marichal González - alu0101646480@ull.edu.es
* @date Oct 12 2023
* @brief El programa calcula la media de cuatro valores introducidos.
* @bug There are no known bugs
* @see https://docs.google.com/document/d/1IVXL8p2OQH20hNdabSTur1dDnDyKI8XYvHtJt19KTjg/edit?usp=sharing
*/


#include <iostream>


int main() {
  double valor_1, valor_2, valor_3, valor_4;

  std::cout << "Introduzca el primer valor: ";
  std::cin >> valor_1;
  std::cout << "Introduzca el segundo valor: ";
  std::cin >> valor_2;
  std::cout << "Introduzca el tercer valor: ";
  std::cin >> valor_3;
  std::cout << "Introduzca el cuarto valor: ";
  std::cin >> valor_4;

  std::cout << "El promedio es: " << (valor_1 + valor_2 + valor_3 + valor_4) / 4
<< std::endl;

  return 0;
}
