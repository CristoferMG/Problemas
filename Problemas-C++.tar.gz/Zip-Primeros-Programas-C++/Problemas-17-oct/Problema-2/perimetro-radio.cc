/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica 2023-2024
*
* @file perimetro-radio.cc
* @author Cristofer Marichal González - alu0101646480@ull.edu.es
* @date Oct 12 2023
* @brief El programa calcula el perímetro y área de un círculo de radio que ha
*        de introducir
* @bug There are no known bugs
* @see https://docs.google.com/document/d/1IVXL8p2OQH20hNdabSTur1dDnDyKI8XYvHtJt19KTjg/edit?usp=sharing
*/


#include <iostream>


int main() {
  int radio;
  
  std::cout << "Introduzca el radio: ";
  std::cin >> radio;
  std::cout << "El perímetro es: " << 2*3.14*radio << std::endl;
  std::cout << "El área es: " << 3.14*radio*radio << std::endl;
  
  return 0;
}
