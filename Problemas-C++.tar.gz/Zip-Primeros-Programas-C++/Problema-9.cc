/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica 2023-2024
*
* @file Problema-9.cc
* @author Cristofer Marichal González - alu0101646480@ull.edu.es
* @date Oct 12 2023
* @brief El programa escribe las pontencias de 2 desde la 0-ésima hasta la puesta
* @bug There are no known bugs
* @see https://docs.google.com/document/d/1IVXL8p2OQH20hNdabSTur1dDnDyKI8XYvHtJt19KTjg/edit?usp=sharing
*/


#include <iostream>


int main() {
  int potencia;
  int numero = 1;

  std::cout << "Introduzca un número: ";
  std::cin >> potencia;

  std::cout << "1 ";
  for (int i = 1; i <= potencia; i++) {
    numero = 2*numero;
    std::cout << numero << " ";
  }
  
  std::cout << std::endl;

  return 0;
}
