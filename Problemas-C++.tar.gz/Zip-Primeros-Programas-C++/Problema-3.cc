/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica 2023-2024
*
* @file Problema-3.cc
* @author Cristofer Marichal González - alu0101646480@ull.edu.es
* @date Oct 12 2023
* @brief El programa convierte de centímetros a pulgadas
* @bug There are no known bugs
* @see https://docs.google.com/document/d/1IVXL8p2OQH20hNdabSTur1dDnDyKI8XYvHtJt19KTjg/edit?usp=sharing
*/


#include <iostream>


int main(){
  int centimetros;
  
  std::cout << "Introduzca la medida (en centímetros): ";
  std::cin >> centimetros;
  std::cout << centimetros << " cm = " << centimetros/2.54 << " in" << std::endl;
 
  return 0;
}
