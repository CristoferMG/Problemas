/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica 2023-2024
*
* @file Problema-7.cc
* @author Cristofer Marichal González - alu0101646480@ull.edu.es
* @date Oct 12 2023
* @brief El programa indica si el triángulo es invalido o qué tipo de triángulo
*        es dependiendo de las medidas de los lados que se introduzcan.
* @bug There are no known bugs
* @see https://docs.google.com/document/d/1IVXL8p2OQH20hNdabSTur1dDnDyKI8XYvHtJt19KTjg/edit?usp=sharing
*/


#include <iostream>


int main(){
  double lado_1, lado_2, lado_3;
  
  std::cout << "Introduzca los lados del triángulo: ";
  std::cin >> lado_1 >> lado_2 >> lado_3;
  
  if (lado_1 + lado_2 > lado_3 && lado_1 + lado_3 > lado_2 && lado_2 + lado_3 >
lado_1){
    if (lado_1 == lado_2 || lado_1 == lado_3 || lado_2 == lado_3){
      std::cout << "El triángulo es isósceles." << std::endl;
    }
    else if ( lado_1 == lado_2 && lado_1 == lado_3){
      std::cout << "El triángulo es equilátero." << std::endl;
    }
    else{
      std::cout << "El triángulo es escaleno." << std::endl;
    }  
  }
  else{
    std::cout << "No es un triángulo válido." << std::endl; 
  }
}
