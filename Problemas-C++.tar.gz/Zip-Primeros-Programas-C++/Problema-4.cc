/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica 2023-2024
*
* @file Problema-4.cc
* @author Cristofer Marichal González - alu0101646480@ull.edu.es
* @date Oct 12 2023
* @brief El programa calcula de hipotenusa de un triángulo rectángulo conociendo
*        sus dos catetos.
* @bug There are no known bugs
* @see https://docs.google.com/document/d/1IVXL8p2OQH20hNdabSTur1dDnDyKI8XYvHtJt19KTjg/edit?usp=sharing
*/


#include <iostream>
#include <cmath>

int main() {
  float cateto_a, cateto_b;

  std::cout << "Introduzca el cateto a: ";
  std::cin >> cateto_a;
  std::cout << "Introduzca el cateto b: ";
  std::cin >> cateto_b;
  std::cout << "El valor de la hipotenusa es: " <<
sqrt((cateto_a * cateto_a) + (cateto_b * cateto_b)) <<
std::endl;

  return 0;
}
