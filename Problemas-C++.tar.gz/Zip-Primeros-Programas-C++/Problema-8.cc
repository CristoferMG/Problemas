/**
* Universidad de La Laguna
* Escuela Superior de Ingeniería y Tecnología
* Grado en Ingeniería Informática
* Informática Básica 2023-2024
*
* @file Problema-8.cc
* @author Cristofer Marichal González - alu0101646480@ull.edu.es
* @date Oct 12 2023
* @brief El programa devuelve la hora que marcaŕa el reloj detro de un número de
*        horas introduccidas por con anterioridad.
* @bug There are no known bugs
* @see https://docs.google.com/document/d/1IVXL8p2OQH20hNdabSTur1dDnDyKI8XYvHtJt19KTjg/edit?usp=sharing
*/


#include <iostream>


int main(){
  int hora, hora_futuras;
  
  std::cout << "Introduzca la hora actual (formato 12h): ";
  std::cin >> hora;
  std::cout << "Introduzca la cantidad de horas: ";
  std::cin >> hora_futuras;

  if (hora > 12){
    std::cout << "La hora debe ser dada en formato 12 horas." << std::endl;
  }
  else if (hora_futuras > 12){
    std::cout << "El número introduccido es superior al permitido (12)." <<
std::endl;
  }
  else if (hora + hora_futuras > 12){
    std::cout << "En " << hora << " horas, el reloj marcará las " << (hora +
hora_futuras) - 12 << "." << std::endl; 
  }
  else{
    std::cout << "En " << hora << " horas, el reloj marcará las " << hora +
hora_futuras << "." << std::endl;
  }
}
